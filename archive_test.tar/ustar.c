#include "ustar.h"

#define USTAR_BLOCK_SIZE 512
#define USTAR_HEADER_SIZE USTAR_BLOCK_SIZE

static ustar_alloc_func ustar_afunc;
static ustar_free_func ustar_ffunc;

static uint64_t _round_up_to_512(uint64_t num) { 
	uint64_t res = num & 0xFFFFFFFFFFFFFE00;
	if (res < num) { 
		res += 512;
	};
	return res;
};

static uint64_t _parse_octal(uint8_t* data, size_t size) { 
	uint64_t n = 0;
	unsigned char* c = data;
	while (size > 0) { 
		n *= 8;
		n += *c - '0';
		c++;
		size--;
	};
	return n;
};

static void _checksum_check(uint8_t* data) { 
	uint64_t num = *((uint64_t*)(data));
	/* TO BE IMPLEMENTED */
};

ustar_type_t _parse_type(uint8_t* data) { 
	unsigned char c = (unsigned char)(*data);
	if (c == '0') { 
		return ustar_type_file;
	};
	return ustar_type_dir;
}


void ustar_init(ustar_alloc_func afunc, ustar_free_func ffunc) { 
	ustar_afunc = afunc;
	ustar_ffunc = ffunc;
};

void* ustar_alloc(size_t size) { 
	return ustar_afunc(size);
};


void ustar_free(void* ptr) { 
	ustar_ffunc(ptr);
};


ustar_t* ustar_new_archive(void) { 
	ustar_t* res = ustar_alloc(sizeof(ustar_t));
	res->entries = ustar_new_entries();

	return res;
}

ustar_entries_t* ustar_new_entries(void) { 
	ustar_entries_t* res = ustar_alloc(sizeof(ustar_entries_t));
	res->entries = LList_create_list();
	res->index = 0;

	return res;
}


ustar_entry_t* ustar_new_entry(void) { 
	ustar_entry_t* res = ustar_alloc(sizeof(ustar_entry_t));
	res->mdata = ustar_new_mdata();
	res->content = ustar_new_data();

	return res;
} 

ustar_data_t* ustar_new_data(void) { 
	ustar_data_t* res = ustar_alloc(sizeof(ustar_data_t));
	memset(res, (int)NULL, sizeof(ustar_data_t));

	return res;
}


ustar_mdata_t* ustar_new_mdata(void) { 
	ustar_mdata_t* res = ustar_alloc(sizeof(ustar_mdata_t));
	memset(res, (int)NULL, sizeof(ustar_mdata_t));

	return res;
}

void ustar_add_entry(ustar_t* archive, ustar_entry_t* entry) { 
	ustar_entries_t* entries = archive->entries;
	LList_add_item_to_end(entries->entries, entry);
}


/* Read */

static void _ustar_parse_mdata(uint8_t* data, ustar_entry_t* entry) { 
	ustar_mdata_t* mdata = entry->mdata;
	ustar_data_t* name = ustar_new_data();
	name->ptr = ustar_alloc(100);
	name->size = 100;
	memcpy(name->ptr, data, 100);
	data += 100;
	
	memcpy(&(mdata->mode), data, 8);
	data += 8;

	memcpy(&(mdata->uid), data, 8);
	data += 8;

	memcpy(&(mdata->gid), data, 8);
	data += 8;
	
	mdata->size = _parse_octal(data, 12);
	data += 12;

	mdata->mtime = _parse_octal(data, 12);
	data += 12;

	memcpy(&(mdata->cksum), data, 8);
	data += 8;

	mdata->type = _parse_type(data);

	ustar_data_t* linkname = ustar_new_data();
	linkname->ptr = ustar_alloc(100);
	linkname->size = 100;
	memcpy(linkname->ptr, data, 100);
	data += 100;
	
	_checksum_check(data);
	data += 8;
	
	ustar_data_t* uname = ustar_new_data();
	uname->ptr = ustar_alloc(32);
	uname->size = 32;
	memcpy(uname->ptr, data, 32);
	data += 32;

	ustar_data_t* gname = ustar_new_data();
	gname->ptr = ustar_alloc(32);
	gname->size = 32;
	memcpy(gname->ptr, data, 32);
	data += 32;

	memcpy(&(mdata->devmajor), data, 8);
	data += 8;

	memcpy(&(mdata->devminor), data, 8);
	data += 8;

	ustar_data_t* prefix = ustar_new_data();
	prefix->ptr = ustar_alloc(32);
	prefix->size = 32;
	memcpy(prefix->ptr, data, 32);
	data += 32;

	mdata->name = name;
	mdata->linkname = linkname;
	mdata->uname = uname;
	mdata->gname = gname;
	mdata->prefix = prefix;
};

static size_t _ustar_parse_content(uint8_t* data, ustar_entry_t* entry) { 
	uint64_t size = entry->mdata->size;
	size = _round_up_to_512(size);
	ustar_data_t* ndata = entry->content;
	ndata->ptr = ustar_alloc(size);
	ndata->size = size;
	memcpy(ndata->ptr, data, size);

	return size;
};

ustar_t* ustar_parse(ustar_data_t* data) { 
	ustar_t* res = ustar_new_archive();
	uint8_t* data_start = data->ptr;
	uint8_t* data_cur = data_start;
	uint8_t* data_end = data_start + data->size;
	while (data_cur < data_end) { 
		ustar_entry_t* nentry = ustar_new_entry();
		_ustar_parse_mdata(data_cur, nentry);
		data_cur += USTAR_HEADER_SIZE;
		size_t size = _ustar_parse_content(data_cur, nentry);
 		data_cur += size;
	}
	return res;
}

ustar_entry_t* ustar_iterate(ustar_t* archive) { 
	ustar_entries_t* entries = archive->entries;
	ustar_entry_t* entry = LList_get_item(entries->entries, entries->index);

	if (entry == NULL) {
		entries->index = 0;
	}

	return entry;
}

/* Update */
ustar_data_t* ustar_serialize(ustar_t* archive) { 
	ustar_data_t* res = ustar_new_data();

	return res;
}


static int _ustar_remove_search(void* item, void* data) { 
	return item == data;
};

/* Destroy */ 
void ustar_remove(ustar_t* archive, ustar_entry_t* entry) { 
	ustar_entries_t* entries = archive->entries;
	int index = LList_search_list(entries->entries, _ustar_remove_search, entry);
	if (index >= 0) { 
		LList_remove_item(entries->entries, index);
	};
}

void ustar_free_archive(ustar_t* archive) { 
	ustar_free_entries(archive->entries);
	ustar_free(archive);
}

void ustar_free_entries(ustar_entries_t* entries) { 
	LList_delete_list(entries->entries);
	ustar_free(entries);
}

void ustar_free_entry(ustar_entry_t* entry) { 
	ustar_free_mdata(entry->mdata);
	ustar_free_data(entry->content);
	ustar_free(entry);
}

void ustar_free_data(ustar_data_t* data) { 
	ustar_free(data->ptr);
	ustar_free(data);
}

void ustar_free_mdata(ustar_mdata_t* mdata) { 
	ustar_free_data(mdata->name);
	ustar_free_data(mdata->linkname);
	ustar_free_data(mdata->uname);
	ustar_free_data(mdata->gname);
	ustar_free_data(mdata->prefix);
	ustar_free(mdata);
}
